# Candidate;
# First and Last Name: Febechukwu Megwalu
# Student ID: 001174229

import csv


# HashTable class using chaining.


class ChainingHashTable:
    # Constructor with optional initial capacity parameter.
    # Assigns all buckets with an empty list.
    def __init__(self, initial_capacity=40):
        # initialize the hash table with empty bucket list entries.
        self.table = []
        for item in range(initial_capacity):
            self.table.append([])

    def insert(self, key, item):  # does both insert and update
        # get the bucket list where this item will go.
        bucket = hash(key) % len(self.table)
        bucket_list = self.table[bucket]

        # update key if it is already in the bucket
        for kv in bucket_list:
            # print (key_value)
            if kv[0] == key:
                kv[1] = item
                return True

        # if not, insert the item to the end of the bucket list.
        key_value = [key, item]
        bucket_list.append(key_value)
        return True

    def search(self, key):
        # get the bucket list where this key would be.
        bucket = hash(key) % len(self.table)
        bucket_list = self.table[bucket]
        # print(bucket_list)

        # search for the key in the bucket list
        for kv in bucket_list:
            # print (key_value)
            if kv[0] == key:
                return kv[1]  # value
        return None

    def remove(self, key):
        # get the bucket list where this item will be removed from.
        bucket = hash(key) % len(self.table)
        bucket_list = self.table[bucket]

        # remove the item from the bucket list if it is present.
        for kv in bucket_list:
            # print (key_value)
            if kv[0] == key:
                bucket_list.remove([kv[0], kv[1]])


# Package Class
class Package:      # Initializes i_d, address, city, state, zipcode, deadline, weight, and delivery_status.
    def __init__(self, i_d, address, city, state, zipcode, deadline, weight, delivery_status):
        self.i_d = i_d
        self.address = address
        self.city = city
        self.state = state
        self.zipcode = zipcode
        self.deadline = deadline
        self.weight = weight
        self.delivery_status = delivery_status

    def __str__(self):  # Print function. To avoid printing object reference.
        return "%s, %s, %s, %s, %s, %s, %s, %s" % (self.i_d, self.address, self.city,
                                                   self.state, self.zipcode, self.deadline,
                                                   self.weight, self.delivery_status)


# Helps load package by reading the given csv data and using it to initialze package. Then adds each of the packages
# to the specified hash table (myHash).
def load_package(file_name, p_note="Loaded"):
    with open(file_name) as loadPackageData:
        package_data = csv.reader(loadPackageData, delimiter=',')
        for myPackage in package_data:
            p_id = int(myPackage[0])
            p_address = myPackage[1]
            p_city = myPackage[2]
            p_state = myPackage[3]
            p_zipcode = myPackage[4]
            p_deadline = myPackage[5]
            p_weight = myPackage[6]

            # Package object
            my_package = Package(p_id, p_address, p_city, p_state, p_zipcode, p_deadline, p_weight, p_note)

            # Insert package into hash table
            myHash.insert(p_id, my_package)


distances2d = []        # Array to hold the distance between each given addresses.


# Loads the distance file using the given loadDistanceData and appends each of them to distances2d.
def load_distance_data(file_name):
    with open(file_name) as loadDistanceData:
        distance_data = csv.reader(loadDistanceData, delimiter=',')

        for row in distance_data:
            distances1d = []
            for distance in row:
                if distance != '':
                    distances1d.append(float(distance))
            distances2d.append(distances1d)


addresses = []          # Array to hold each address


# Loads each address to addresses array, using the address retrieved from loadAddressData file.
def load_address_data(file_name):
    with open(file_name) as loadAddressData:
        address_data = csv.reader(loadAddressData, delimiter=',')

        for address in address_data:
            addresses.append(address[0])
            print(address[0])    # For debugging


# Returns distance between two addresses
def distance_between(address1, address2):
    # If else ensure we are checking the row and col in the right order. Because matrix can be inverted at any call.
    if addresses.index(address1) > addresses.index(address2):
        row_index = addresses.index(address1)
        col_index = addresses.index(address2)
    else:
        row_index = addresses.index(address2)
        col_index = addresses.index(address1)

    # print(f"\ndistances2d prior: {distances2d}")
    # print(f"add1: {address1}, add2: {address2}")
    # print(f"rowIndex: {row_index}, colIndex: {col_index}")
    # print(f"distances2d: {distances2d[row_index][col_index]}\n")
    return distances2d[row_index][col_index]  # Retrieves distance index based on which row and which col


def min_distance_from(from_address, truck_packages):
    min_d = 20  # since no distance in distances is greater than 20
    return_package = truck_packages[0]
    for my_package in truck_packages:
        my_distance = distance_between(from_address, my_package.address)
        # print(f"my dist: {my_distance} min_d: {min_d}")  # for debugging
        if my_distance < min_d and my_distance != 0:
            min_d = my_distance
            return_package = my_package
    return return_package


# My hash table instance
myHash = ChainingHashTable()

# Load packages to Hash Table
load_package('packageData.csv')
# Load distance data
load_distance_data('distanceData.csv')
# Load address data
load_address_data('addressData.csv')

# Fetching data from Hash table
for i in range(len(myHash.table)):
    print("Key: {} and Packages: {}".format(i + 1, myHash.search(i + 1)))  # 1 to 40 is sent to myHash.search()

# New line
print()

# Print addresses
index = 0
for element in addresses:
    print(f"Index: {index}; Address: {element}")
    index = index + 1

print()

# To test distances2d
index = 0
for element in distances2d:
    print(f"Index: {index}; Distance: {element}")
    index = index + 1

# Print addresses To test min_distance_from
index = 0
for element in addresses:
    # print(f"Min Distance From Address: {element}, To: {min_distance_from(element, truck1packages)}")
    index = index + 1

print('\n ------------------------------------------------------------------ \n')

# Packages in which truck they belong to
truck1packages = []
truck2packages = []
truck3packages = []

# Loading truck one
truck1packages.append(myHash.search(15))  # Pid 15 deadline is 9:00am
truck1packages.append(myHash.search(13))  # Pid 13 deadline is 10:30am
truck1packages.append(myHash.search(20))  # Pid 20 deadline is 10:30am (must be delivered with 15 and 13)
truck1packages.append(myHash.search(14))  # Pid 14 deadline is 10:30am
truck1packages.append(myHash.search(16))  # Pid 16 deadline is 10:30am
truck1packages.append(myHash.search(19))  # Pid 14 and 16 must be delivered with 19
truck1packages.append(myHash.search(29))  # Pid 29 deadline is 10:30am
truck1packages.append(myHash.search(30))  # Pid 30 deadline is 10:30am
truck1packages.append(myHash.search(31))  # Pid 31 deadline is 10:30am
truck1packages.append(myHash.search(34))  # Pid 34 deadline is 10:30am
truck1packages.append(myHash.search(37))  # Pid 37 deadline is 10:30am
truck1packages.append(myHash.search(40))  # Pid 40 deadline is 10:30am

# Loops through each package and ensure they meet the specified constraints in the for loop then appends
# the packages that satisfied the constraints into truck1packages.
for i in range(20):
    package = myHash.search(i + 1)
    # pid 9 has wrong address, pid 3 can only be on truck 2, pid 6 arrival is delayed, pid 18 can only be on truck 2,
    # and truck one is not yet full (16 packages at most), pid 25, 28, and 32 will not arrive until 9:05am
    if ((i + 1) != 9) and ((i + 1) != 3) and ((i + 1) != 6 and ((i + 1) != 18) and (len(truck1packages) < 16)
                                              and (i + 1) != 25 and (i + 1) != 28 and (i + 1) != 32 and (
                                                      package not in truck1packages)):
        print(f"Truck 1, Key: {i + 1}, Packages: {package}")
        truck1packages.append(package)
print(f"Truck 1 total packages: {len(truck1packages)}")
print('\n ------------------------------------------------------------------ \n')

# Loading truck two (Leaves at 9:05am after loading; because of package 6 deadline and arrival.
# And because of similar packages)

truck2packages.append(myHash.search(36))  # Pid 36 can only be on truck 2
truck2packages.append(myHash.search(38))  # Pid 38 can only be on truck 2
for i in range(40):
    package = myHash.search(i + 1)
    # if package is not in truck 1, truck 2 is not yet full (16 packages), package 6 arrives at 9:05am,
    # package 9 address will be corrected at 10:20am, pid 28 and 32 arrives 9:05am
    if (package not in truck1packages) and (len(truck2packages) < 16) and ((i + 1) != 9) \
            and ((i + 1) != 28) and ((i + 1) != 32):
        print(f"Truck 2, Key: {i + 1}, Packages: {package}")
        truck2packages.append(package)
print(f"Truck 2 total packages: {len(truck2packages)}")
print('\n ------------------------------------------------------------------ \n')

# Scheduling truck 3 to be loaded at 10:20am, which is when the last package address will be corrected.
for i in range(40):
    package = myHash.search(i + 1)
    # if package is not in truck 1 and package not in truck 2
    if (package not in truck1packages) and (package not in truck2packages):
        package.delivery_status = "Scheduled to be loaded at 10:20am"
        print(f"Truck 3, Key: {i + 1}, Packages: {package}")
        truck3packages.append(package)
print(f"Truck 3 total packages: {len(truck3packages)}")
print('\n ------------------------------------------------------------------ ')
print('                  Delivering Execution Starts Now  ')
print(' ------------------------------------------------------------------ \n')

total_miles_by_all_trucks = 0.0     # for keeping track of total truck miles
t1remainingPackages = []        # keeps track of truck 1 remaining packages
t2remainingPackages = []        # keeps track of truck 2 remaining packages
t3remainingPackages = []        # keeps track of truck 3 remaining packages
t1hours = 8  # driver 1 departs at 8am
t2hours = 9  # driver 2 departs at 9:05am
t3hours = 10  # truck 3 leaves at 10:37am
t1minutes = 0               # keeps track of truck 1 elapsed minutes
t2minutes = 5               # keeps track of truck 2 elapsed minutes
t3minutes = 37              # keeps track of truck 3 elapsed minutes
t1elapsed_hours = 0     # keeps track of truck 1 elapsed hours
t2elapsed_hours = 0     # keeps track of truck 2 elapsed hours
t3elapsed_hours = 0     # keeps track of truck 3 elapsed hours
truck1miles = 0.0       # keeps track of truck 1 elapsed miles
truck2miles = 0.0       # keeps track of truck 2 elapsed miles
truck3miles = 0.0       # keeps track of truck 3 elapsed miles
truck1total_miles = 0.0     # keeps track of truck 1 total miles
truck2total_miles = 0.0     # keeps track of truck 2 total miles
truck3total_miles = 0.0     # keeps track of truck 3 total miles
truck1location = "HUB"      # truck 1 location
truck2location = "HUB"      # truck 2 location
truck3location = "HUB"      # truck 3 locatoin
currTime = '8:00 AM'
amOrPm1 = 'AM'              # for truck 1
amOrPm2 = 'AM'              # for truck 2
amOrPm3 = 'AM'              # for truck 3
i = -1
deliveryTimesHr = [0 for i in range(41)]
deliveryTimesMin = [0 for i in range(41)]
deliveryTimesAmOrPm = ['' for i in range(41)]
truckstotalmiles = [0 for i in range(41)]

# Deliver 9:00 AM package (Truck 1)
while len(truck1packages) > 15:
    i = i + 1
    if i >= len(truck1packages):
        i = 0
    package = truck1packages[i]

    if package.deadline == '9:00 AM':  # Prioritize 9:00am(deadline) packages
        truck1miles = distance_between(truck1location, package.address)
        t1elapsed_hours = (truck1miles / 18) + t1elapsed_hours  # elapsed time = traveled miles / truck speed (mph)
        if t1elapsed_hours < 1:  # to convert hours to minutes
            t1minutes = int(t1elapsed_hours * 60) + t1minutes
            t1elapsed_hours = 0
        if t1minutes >= 60:  # to convert minutes to hours
            t1elapsed_hours = int(t1minutes / 60)
            t1minutes = t1minutes - (t1elapsed_hours * 60)
        # print(f"ELAPSED HOUR: {t1elapsed_hours}, T1MINUTES: {t1minutes}")
        t1hours = t1hours + t1elapsed_hours
        if (t1hours + t1elapsed_hours) >= 12:
            amOrPm1 = 'PM'
        # print(f"T1 time: {t1hours}:{t1minutes} {amOrPm}")
        currTime = f"{t1hours}:{t1minutes} {amOrPm1}"
        myHash.search(package.i_d).delivery_status = f"Delivered at {currTime}"
        deliveryTimesHr[package.i_d] = t1hours
        deliveryTimesMin[package.i_d] = t1minutes
        deliveryTimesAmOrPm[package.i_d] = amOrPm1
        print(myHash.search(package.i_d))
        truck1total_miles = truck1total_miles + truck1miles  # adding truck's total miles
        truck1location = package.address  # Update truck location
        truck1packages.remove(package)  # offload package when at delivery destination
        total_miles_by_all_trucks = truck1miles + total_miles_by_all_trucks
        truckstotalmiles[package.i_d] = truck1miles

    t1elapsed_hours = 0

# Deliver 10:30 AM packages and EOD packages on time (Truck 1).
while len(truck1packages) > 0:
    i = i + 1
    if i >= len(truck1packages):
        i = 0
    package = min_distance_from(truck1location, truck1packages)
    # print(f"MINIMUM DIST PACK: {package}")
    if package.deadline == '10:30 AM' or package.deadline == "EOD":  # Prioritize 10:30am(deadline) packages
        truck1miles = distance_between(truck1location, package.address)
        t1elapsed_hours = (truck1miles / 18) + t1elapsed_hours  # elapsed time = traveled miles / truck speed (mph)
        if t1elapsed_hours < 1:  # to convert hours to minutes
            t1minutes = int(t1elapsed_hours * 60) + t1minutes
            t1elapsed_hours = 0
        if t1minutes >= 60:  # to convert minutes to hours
            t1elapsed_hours = int(t1minutes / 60)
            t1minutes = t1minutes - (t1elapsed_hours * 60)
        # print(f"ELAPSED HOUR: {t1elapsed_hours}, T1MINUTES: {t1minutes}")
        t1hours = t1hours + t1elapsed_hours
        if (t1hours + t1elapsed_hours) >= 12:
            amOrPm1 = 'PM'
        # print(f"T1 time: {t1hours}:{t1minutes} {amOrPm}")
        currTime = f"{t1hours}:{t1minutes} {amOrPm1}"
        myHash.search(package.i_d).delivery_status = f"Delivered at {currTime}"
        deliveryTimesHr[package.i_d] = t1hours
        deliveryTimesMin[package.i_d] = t1minutes
        deliveryTimesAmOrPm[package.i_d] = amOrPm1
        print(myHash.search(package.i_d))
        truck1total_miles = truck1total_miles + truck1miles
        truck1location = package.address  # Update truck location
        truck1packages.remove(package)  # offload package when at delivery destination
        total_miles_by_all_trucks = truck1miles + total_miles_by_all_trucks
        truckstotalmiles[package.i_d] = truck1miles

    elif package.deadline != '10:30 AM':
        t1remainingPackages.append(package)
        truck1packages.remove(package)
        total_miles_by_all_trucks = truck1miles + total_miles_by_all_trucks
        truckstotalmiles[package.i_d] = truck1miles

    t1elapsed_hours = 0
print(f"--------------------------Truck 1 remaining packages: {len(truck1packages)}-------------------------")
print("--------------------------------------------------------------------------------")

# Deliver 10:30 AM package (Truck 2)  {Note: Truck 2 departs at 9:05am}
while len(truck2packages) > 14:
    i = i + 1
    if i >= len(truck2packages):
        i = 0
    package = truck2packages[i]

    if package.deadline == '10:30 AM':  # Prioritize 10:30am(deadline) packages
        truck2miles = distance_between(truck2location, package.address)
        t2elapsed_hours = (truck2miles / 18) + t2elapsed_hours  # elapsed time = traveled miles / truck speed (mph)
        if t2elapsed_hours < 1:  # to convert hours to minutes
            t2minutes = int(t2elapsed_hours * 60) + t2minutes
            t2elapsed_hours = 0
        if t2minutes >= 60:  # to convert minutes to hours
            t2elapsed_hours = int(t2minutes / 60)
            t2minutes = t2minutes - (t2elapsed_hours * 60)
        # print(f"ELAPSED HOUR: {t2elapsed_hours}, T2MINUTES: {t2minutes}")
        t2hours = t2hours + t2elapsed_hours
        if (t2hours + t2elapsed_hours) >= 12:
            amOrPm2 = 'PM'
        # print(f"T2 time: {t2hours}:{t2minutes} {amOrPm}")
        currTime = f"{t2hours}:{t2minutes} {amOrPm2}"
        myHash.search(package.i_d).delivery_status = f"Delivered at {currTime}"
        deliveryTimesHr[package.i_d] = t2hours
        deliveryTimesMin[package.i_d] = t2minutes
        deliveryTimesAmOrPm[package.i_d] = amOrPm2
        print(myHash.search(package.i_d))
        truck2total_miles = truck2total_miles + truck2miles
        truck2location = package.address  # Update truck location
        truck2packages.remove(package)  # offload package when at delivery destination
        total_miles_by_all_trucks = truck2miles + total_miles_by_all_trucks
        truckstotalmiles[package.i_d] = truck2miles

    t1elapsed_hours = 0

# Deliver remaining packages in Truck 2
while len(truck2packages) > 0:
    i = i + 1
    if i >= len(truck2packages):
        i = 0
    package = min_distance_from(truck2location, truck2packages)
    # print(f"MINIMUM DIST PACK: {package}")
    if package.deadline == '10:30 AM' or package.deadline == "EOD":  # Prioritize 10:30am(deadline) packages
        truck2miles = distance_between(truck2location, package.address)
        t2elapsed_hours = (truck2miles / 18) + t2elapsed_hours  # elapsed time = traveled miles / truck speed (mph)
        if t2elapsed_hours < 1:  # to convert hours to minutes
            t2minutes = int(t2elapsed_hours * 60) + t2minutes
            t2elapsed_hours = 0
        if t2minutes >= 60:  # to convert minutes to hours
            t2elapsed_hours = int(t2minutes / 60)
            t2minutes = t2minutes - (t2elapsed_hours * 60)
        # print(f"ELAPSED HOUR: {t2elapsed_hours}, T2MINUTES: {t2minutes}")
        t2hours = t2hours + t2elapsed_hours
        if t2hours >= 12:
            amOrPm2 = 'PM'
        # print(f"T2 time: {t2hours}:{t2minutes} {amOrPm}")
        currTime = f"{t2hours}:{t2minutes} {amOrPm2}"
        myHash.search(package.i_d).delivery_status = f"Delivered at {currTime}"
        deliveryTimesHr[package.i_d] = t2hours
        deliveryTimesMin[package.i_d] = t2minutes
        deliveryTimesAmOrPm[package.i_d] = amOrPm2
        print(myHash.search(package.i_d))               # for debugging
        truck2total_miles = truck2total_miles + truck2miles
        truck2location = package.address  # Update truck location
        truck2packages.remove(package)  # offload package when at delivery destination
        total_miles_by_all_trucks = truck2miles + total_miles_by_all_trucks
        truckstotalmiles[package.i_d] = truck2miles

    elif package.deadline != '10:30 AM':
        t2remainingPackages.append(package)
        truck2packages.remove(package)
        total_miles_by_all_trucks = truck2miles + total_miles_by_all_trucks
        truckstotalmiles[package.i_d] = truck2miles

    t2elapsed_hours = 0
print(f"--------------------------Truck 2 remaining packages: {len(truck2packages)}-------------------------")
print("--------------------------------------------------------------------------------")

truck1miles = distance_between(truck1location, "HUB")
t1elapsed_hours = (truck1miles / 18)  # elapsed time = traveled miles / truck speed (mph)
if t1elapsed_hours < 1:  # to convert hours to minutes
    t1minutes = int(t1elapsed_hours * 60) + t1minutes
    t1elapsed_hours = 0
if t1minutes >= 60:  # to convert minutes to hours
    t1elapsed_hours = int(t1minutes / 60)
    t1minutes = t1minutes - (t1elapsed_hours * 60)
# print(f"ELAPSED HOUR: {t1elapsed_hours}, T1MINUTES: {t1minutes}")
t1hours = t1hours + t1elapsed_hours
if (t1hours + t1elapsed_hours) >= 12:
    amOrPm1 = 'PM'
    # print(f"T1 time: {t1hours}:{t1minutes} {amOrPm}")
currTime = f"{t1hours}:{t1minutes} {amOrPm1}"
print(f"Driver 1 returns at: {currTime}")
t1elapsed_hours = 0

# Deliver packages in Truck 3  (Truck 3 departs at 10:37am because that is when driver 1 will be back at HUB)
while len(truck3packages) > 0:
    i = i + 1
    if i >= len(truck3packages):
        i = 0
    package = min_distance_from(truck3location, truck3packages)
    # print(f"MINIMUM DIST PACK: {package}")
    if package.deadline == '10:30 AM' or package.deadline == "EOD":  # Prioritize 10:30am(deadline) packages
        truck3miles = distance_between(truck3location, package.address)
        t3elapsed_hours = (truck3miles / 18) + t3elapsed_hours  # elapsed time = traveled miles / truck speed (mph)
        if t3elapsed_hours < 1:  # to convert hours to minutes
            t3minutes = int(t3elapsed_hours * 60) + t3minutes
            t3elapsed_hours = 0
        if t3minutes >= 60:  # to convert minutes to hours
            t3elapsed_hours = int(t3minutes / 60)
            t3minutes = t3minutes - (t3elapsed_hours * 60)
        # print(f"ELAPSED HOUR: {t3elapsed_hours}, T3MINUTES: {t3minutes}")
        t3hours = t3hours + t3elapsed_hours
        if t3hours >= 12:
            amOrPm3 = 'PM'
        # print(f"T2 time: {t2hours}:{t2minutes} {amOrPm}")
        if int(t3hours % 12) == 0 and amOrPm3 == 'PM':
            currTime = f"{12}:{t3minutes} {amOrPm3}"
        else:
            currTime = f"{int(t3hours % 12)}:{t3minutes} {amOrPm3}"
        myHash.search(package.i_d).delivery_status = f"Delivered at {currTime}"
        deliveryTimesHr[package.i_d] = t3hours
        deliveryTimesMin[package.i_d] = t3minutes
        deliveryTimesAmOrPm[package.i_d] = amOrPm3
        print(myHash.search(package.i_d))
        truck3total_miles = truck3total_miles + truck3miles
        truck3location = package.address  # Update truck location
        truck3packages.remove(package)  # offload package when at delivery destination
        total_miles_by_all_trucks = truck3miles + total_miles_by_all_trucks
        truckstotalmiles[package.i_d] = truck3miles

    elif package.deadline != '10:30 AM':
        t3remainingPackages.append(package)
        truck3packages.remove(package)
        total_miles_by_all_trucks = truck3miles + total_miles_by_all_trucks
        truckstotalmiles[package.i_d] = truck3miles

    t3elapsed_hours = 0
print(f"--------------------------Truck 3 remaining packages: {len(truck3packages)}-------------------------")
print("--------------------------------------------------------------------------------")

print(f"Total Travelled Distance of All Trucks: {total_miles_by_all_trucks}")

# reLoading truck one for user to check delivery at anytime
truck1packages.append(myHash.search(15))  # Pid 15 deadline is 9:00am
truck1packages.append(myHash.search(13))  # Pid 13 deadline is 10:30am
truck1packages.append(myHash.search(20))  # Pid 20 deadline is 10:30am (must be delivered with 15 and 13)
truck1packages.append(myHash.search(14))  # Pid 14 deadline is 10:30am
truck1packages.append(myHash.search(16))  # Pid 16 deadline is 10:30am
truck1packages.append(myHash.search(19))  # Pid 14 and 16 must be delivered with 19
truck1packages.append(myHash.search(29))  # Pid 29 deadline is 10:30am
truck1packages.append(myHash.search(30))  # Pid 30 deadline is 10:30am
truck1packages.append(myHash.search(31))  # Pid 31 deadline is 10:30am
truck1packages.append(myHash.search(34))  # Pid 34 deadline is 10:30am
truck1packages.append(myHash.search(37))  # Pid 37 deadline is 10:30am
truck1packages.append(myHash.search(40))  # Pid 40 deadline is 10:30am

for i in range(20):
    package = myHash.search(i + 1)
    # pid 9 has wrong address, pid 3 can only be on truck 2, pid 6 arrival is delayed, pid 18 can only be on truck 2,
    # and truck one is not yet full (16 packages at most), pid 25, 28, and 32 will not arrive until 9:05am
    if ((i + 1) != 9) and ((i + 1) != 3) and ((i + 1) != 6 and ((i + 1) != 18) and (len(truck1packages) < 16)
                                              and (i + 1) != 25 and (i + 1) != 28 and (i + 1) != 32 and (
                                                      package not in truck1packages)):
        print(f"Truck 1, Key: {i + 1}, Packages: {package}")
        truck1packages.append(package)
print(f"Truck 1 total packages: {len(truck1packages)}")
print('\n ------------------------------------------------------------------ \n')

# Loading truck two (Leaves at 9:05am after loading; because of package 6 deadline and arrival.
# And because of similar packages)

truck2packages.append(myHash.search(36))  # Pid 36 can only be on truck 2
truck2packages.append(myHash.search(38))  # Pid 38 can only be on truck 2
for i in range(40):
    package = myHash.search(i + 1)
    # if package is not in truck 1, truck 2 is not yet full (16 packages), package 6 arrives at 9:05am,
    # package 9 address will be corrected at 10:20am, pid 28 and 32 arrives 9:05am
    if (package not in truck1packages) and (len(truck2packages) < 16) and ((i + 1) != 9) \
            and ((i + 1) != 28) and ((i + 1) != 32):
        print(f"Truck 2, Key: {i + 1}, Packages: {package}")
        truck2packages.append(package)
print(f"Truck 2 total packages: {len(truck2packages)}")
print('\n ------------------------------------------------------------------ \n')

# Scheduling truck 3 to be loaded at 10:20am, which is when the last package address will be corrected.
for i in range(40):
    package = myHash.search(i + 1)
    # if package is not in truck 1 and package not in truck 2
    if (package not in truck1packages) and (package not in truck2packages):
        package.delivery_status = "Scheduled to be loaded at 10:20am"
        print(f"Truck 3, Key: {i + 1}, Packages: {package}")
        truck3packages.append(package)
print(f"Truck 3 total packages: {len(truck3packages)}")


# Ask user if they want to check status of all packages or status of one package
print("----------------------------------------------------------------------------")
# Ask user to enter hour and minute and time of day (AM or PM) to check for package
userDecision = int(input("To check status of all packages enter 1, to check status of a single package enter 2: "))
print("----------------------------------------------------------------------------")

if userDecision == 1:
    # Query user for real time update
    print("----------------------------------------------------------------------------")
    # Ask user to enter hour and minute and time of day (AM or PM) to check for package
    enteredHr = int(input("Enter Time Hour: "))    # Gets hour of interest
    enteredMin = int(input("Enter Time Min: "))    # Gets minute of interest
    enteredAmOrPm = input("Enter Time AM or PM (All caps and no other char): ")   # Gets period of day
    total_miles_by_all_trucks = 0

    # Loops through all 40 packages
    for i in range(40):
        searchedPackage = myHash.search(i + 1)              # checks each package starting from package 1
        foundPackageHr = deliveryTimesHr[searchedPackage.i_d]           # keeps track of delivery hour
        foundPackageMin = deliveryTimesMin[searchedPackage.i_d]         # keeps track of delivery minute
        foundPackageAmOrPm = deliveryTimesAmOrPm[searchedPackage.i_d]
        if ((enteredHr > foundPackageHr and enteredAmOrPm == foundPackageAmOrPm)
                or (enteredHr == foundPackageHr and enteredMin > foundPackageMin) or
                (enteredAmOrPm == 'PM' and foundPackageAmOrPm == 'AM')):
            searchedPackage.delivery_status = f"Package has been delivered at {foundPackageHr}:{foundPackageMin} " \
                                              f"{foundPackageAmOrPm}"  # to print delivered package and time of delivery
            total_miles_by_all_trucks = truckstotalmiles[searchedPackage.i_d] + total_miles_by_all_trucks

        elif ((searchedPackage in truck1packages and (enteredHr < 8) or (enteredAmOrPm == 'PM' and
                                                                         foundPackageAmOrPm == 'AM')) or
              (searchedPackage in truck2packages and (enteredHr < 9 or (enteredHr == 9 and enteredMin <= 5)))):
            searchedPackage.delivery_status = f"Package is at the hub"  # To print packages in hub

        elif searchedPackage in truck3packages and (enteredHr <= 10 or (enteredHr <= 10 and enteredMin < 37) or
                                                    enteredHr == 10 and enteredMin < 37) or (
                enteredAmOrPm == 'PM' and foundPackageAmOrPm == 'AM'):
            searchedPackage.delivery_status = f"Package is at the hub"  # To print packages in hub

        else:
            searchedPackage.delivery_status = f"Package en route"  # To print packages in route

        print(searchedPackage)          # prints status of package

    print(f"Total mileage travelled by all trucks {total_miles_by_all_trucks}")   # prints total packages
    print("----------------------------------------------------------------------------")


if userDecision == 2:
    # Query user for real time update for a specific package
    print("----------------------------------------------------------------------------")
    # Ask user to enter hour and minute and time of day (AM or PM) to check for package
    selectedPackageID = int(input("Enter specific package ID: "))  # Gets specific package ID of interest
    enteredHr = int(input("Enter Time Hour: "))   # Gets hour of interest
    enteredMin = int(input("Enter Time Min: "))   # Gets minute of interest
    enteredAmOrPm = input("Enter Time AM or PM (All caps and no other char): ")   # Gets period of day
    total_miles_by_all_trucks = 0

    # Checks for status of a specific package
    for i in range(40):
        searchedPackage = myHash.search(i + 1)              # checks each package starting from package 1
        foundPackageHr = deliveryTimesHr[searchedPackage.i_d]           # keeps track of delivery hour
        foundPackageMin = deliveryTimesMin[searchedPackage.i_d]         # keeps track of delivery minute
        foundPackageAmOrPm = deliveryTimesAmOrPm[searchedPackage.i_d]
        if ((enteredHr > foundPackageHr and enteredAmOrPm == foundPackageAmOrPm)
                or (enteredHr == foundPackageHr and enteredMin > foundPackageMin) or
                (enteredAmOrPm == 'PM' and foundPackageAmOrPm == 'AM')):
            searchedPackage.delivery_status = f"Package has been delivered at {foundPackageHr}:{foundPackageMin} " \
                                              f"{foundPackageAmOrPm}"  # to print delivered package and time of delivery
            total_miles_by_all_trucks = truckstotalmiles[searchedPackage.i_d] + total_miles_by_all_trucks

        elif ((searchedPackage in truck1packages and (enteredHr < 8) or (enteredAmOrPm == 'PM' and
                                                                         foundPackageAmOrPm == 'AM')) or
              (searchedPackage in truck2packages and (enteredHr < 9 or (enteredHr == 9 and enteredMin <= 5)))):
            searchedPackage.delivery_status = f"Package is at the hub"                  # To print packages in hub

        elif searchedPackage in truck3packages and (enteredHr <= 10 or (enteredHr <= 10 and enteredMin < 37) or
             enteredHr == 10 and enteredMin < 37) or (enteredAmOrPm == 'PM' and foundPackageAmOrPm == 'AM'):
            searchedPackage.delivery_status = f"Package is at the hub"          # To print packages in hub

        else:
            searchedPackage.delivery_status = f"Package en route"   # To print packages in route

    print(myHash.search(selectedPackageID))          # prints status of the selected package

    print(f"Total mileage travelled by all trucks {total_miles_by_all_trucks}")   # prints total packages
    print("----------------------------------------------------------------------------")
